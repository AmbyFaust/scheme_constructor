rendering_widget_width = 400
rendering_widget_height = 400

primitive_width = 100
primitive_height = 50

block_width = primitive_width
block_height = primitive_height

pin_width = 16
pin_height = 16

width_wire = 15  # должно быть нечетным
